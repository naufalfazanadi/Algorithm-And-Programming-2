#include "header.h"
int main(){
	temp = 7; //define var color = 7
	home();
	return 0;
}